export interface Category {
  id: string;
  name: string;
  urlHandle: string;
}
